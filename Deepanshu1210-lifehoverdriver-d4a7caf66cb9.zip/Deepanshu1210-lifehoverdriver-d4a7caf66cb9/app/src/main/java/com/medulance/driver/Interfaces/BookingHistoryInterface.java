package com.medulance.driver.Interfaces;

/**
 * Created by sahil on 27/8/16.
 */
public interface BookingHistoryInterface {
    public void onClick(int pos);
}
