package com.medulance.driver.Interfaces;

/**
 * Created by sahil on 13/9/16.
 */
public interface GetGCMTokenInterface{
        void getResult(String result);
}
