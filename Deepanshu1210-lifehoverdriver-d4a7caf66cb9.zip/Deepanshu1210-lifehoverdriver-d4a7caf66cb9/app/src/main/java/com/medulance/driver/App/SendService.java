package com.medulance.driver.App;

/**
 * Created by Sahil on 03/07/2016.
 */

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.medulance.driver.Interfaces.IOkHttpNotify;
import com.medulance.driver.helper.SessionManager;
import com.medulance.driver.okhttp.OKHttpAPICalls;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.io.IOException;

public class SendService extends Service implements LocationListener {
    LocationManager locationManager;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000 * 10, 0, this);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000 * 10, 0, this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("LocalService", "Received start id " + startId + ": " + intent);
        return START_STICKY;
    }

    @Override
    public void onLocationChanged(Location location) {
        sendIntent(location.getLatitude(), location.getLongitude());
        sendData(location.getLatitude(), location.getLongitude());
    }

    private void sendIntent(double latitude, double longitude) {
        MyApplication.getInstance().setLatLng(latitude, longitude);
        Intent intent = new Intent();
        intent.setAction(Constants.Extras.LOCATION_BROADCAST);
        intent.putExtra(Constants.IntentParameters.TYPE, Constants.Extras.LOCATION_BROADCAST_TYPE);
        intent.putExtra(Constants.IntentParameters.LATITUDE, latitude);
        intent.putExtra(Constants.IntentParameters.LONGITUDE, longitude);
        sendBroadcast(intent);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    private void sendData(double lat, double lng) {
        SessionManager sessionManager = new SessionManager(this);
        OKHttpAPICalls okHttpAPICalls = new OKHttpAPICalls();
        Bundle bundle = new Bundle();
        bundle.putDouble(Constants.Extras.LATITUDE, lat);
        bundle.putDouble(Constants.Extras.LONGITUDE, lng);
        bundle.putString(Constants.Extras.DRIVER, sessionManager.getKeyUserId());
        if (sessionManager.getKeyUserId() == null) {
            return;
        }
        okHttpAPICalls.run(Constants.RequestTags.SEND_LOCATION, bundle);
        okHttpAPICalls.setOnOkHttpNotifyListener(new IOkHttpNotify() {
            @Override
            public void onHttpRequestSuccess(String requestType, Response response) throws IOException {
                String jsonResponse = response.body().string();
            }

            @Override
            public void onHttpRequestFailure(String requestType, Request request, String errorMessage) {

            }
        });
    }

    @Override
    public void onDestroy() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.removeUpdates(this);
        super.onDestroy();
    }
}
